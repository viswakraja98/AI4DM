let video;
let label = "waiting...";
let classifier;
let modelURL = 'https://teachablemachine.withgoogle.com/models/A44tJ5w7e/';

let mountainsDrawn = false;
let mountainXOffset = 0;
let sun = 400;
let sunAnimating = true; // Control sun animation
let sunVisible = false; // Control sun visibility
let mountainColumn = ""; // Variable to store which column the mountain is in
let lastSpokenColumn = ""; // Keep track of last spoken column for TTS


function preload() {
  classifier = ml5.imageClassifier(modelURL + 'model.json');
}

let red = 255;
let green = 104;
let blue = 50;
let bgAlpha = 200; // Alpha for background transparency

function setup() {
  createCanvas(1000, 500);
  // Create the video
  video = createCapture(VIDEO, { flipped: true });
  video.size(width, height);
  video.hide();


  // Start classifying
  classifier.classifyStart(video, gotResult);
}

function draw() {
  // Draw the video first
  image(video, 0, 0, width, height);

  // Draw the grid columns
  drawGrid();  

  background(red++, green++, blue, bgAlpha);

  // Update colors or add more logic based on label classification here
  // Draw the sun when label is "sun"
if (label === "sun") {
    sunVisible = true; // Make the sun visible when the label is "sun"
  }

  if (sunVisible) {
    drawSun(); // Draw the sun if it has been made visible
  }

  // Toggle the mountain drawing when the label is "mountain"
  if (label === "mountain") {
    mountainsDrawn = true;
    label = ""; // Reset label to avoid retriggering
  }

  // Move mountains to the right when label is "right"
  if (label === "right") {
    mountainXOffset += 5;
    label = ""; // Reset label
  }

  // Move mountains to the left when label is "left"
  if (label === "left") {
    mountainXOffset -= 5;
    label = ""; // Reset label
  }

  // Remove all drawings when the label is "remove"
  if (label === "remove") {
    mountainsDrawn = false;
    sun = height;
    sunAnimating = true; // Allow the sun to animate again when label "sun" appears
    sunVisible = false; // Make the sun disappear after "remove"
    label = ""; // Reset label
    mountainColumn = ""; // Clear mountain column text
  }

  // Draw mountains if they are toggled on
  if (mountainsDrawn) {
    drawMountains(mountainXOffset);
    checkMountainLocation(); // Call this to check where the mountain is
  }

  // Draw the text indicating which column the mountain is in
  drawMountainColumnText();
}

function drawGrid() {
  // Divide the canvas into 3 equal columns
  stroke(0);
  line(width / 3, 0, width / 3, height);  // First line dividing column 1 and 2
  line((width / 3) * 2, 0, (width / 3) * 2, height);  // Second line dividing column 2 and 3

  // Label the columns
  textSize(32);
  fill(0);
  text("1", width / 6, 50); // Column 1 label
  text("2", width / 2, 50); // Column 2 label
  text("3", (5 * width) / 6, 50); // Column 3 label
}

function drawSun() {
  noStroke();
  fill(255, 0, 78, 50);
  // Animate the sun until it reaches the top
  if (sun > 100 && sunAnimating) {
    sun -= 5;
    circle(500, sun, 200);
  } else {
    sunAnimating = false;  // Stop animation when the sun reaches the top
    circle(500, 100, 200);  // Keep the sun at the top
  }

  fill(255, 100, 100);
  if (sun > 100 && sunAnimating) {
    sun--;
    circle(500, sun, 180);
  } else {
    circle(500, 100, 180);  // Keep the smaller sun at the top
  }
}

function drawMountains(xOffset) {
  // Draw mountains based on xOffset
  noStroke();
  fill(120, 120, 120);
  triangle(0 + xOffset, 500, 250 + xOffset, 250, 500 + xOffset, 500);
  fill(70, 70, 70);
  triangle(200 + xOffset, 500, 450 + xOffset, 200, 800 + xOffset, 500);
}

function checkMountainLocation() {
  // Calculate the center of the mountains
  let mountainCenter = 250 + mountainXOffset;

  // Determine which column the mountain is in
  if (mountainCenter < width / 3) {
    mountainColumn = "The mountain is on the left side";
  } else if (mountainCenter >= width / 3 && mountainCenter < (width / 3) * 2) {
    mountainColumn = "The mountain is in the middle";
  } else {
    mountainColumn = "The mountain is on the right side";
  }
    // Speak the column text if it has changed
  if (mountainColumn !== lastSpokenColumn) {
    speakColumn(mountainColumn);
    lastSpokenColumn = mountainColumn;
  }
}

function drawMountainColumnText() {
  // Draw the mountain location text at the bottom center
  textAlign(CENTER, BOTTOM);
  textSize(24);
  fill(255);
  text(mountainColumn, width / 2, height - 20);
}

// Function to generate speech output for the column
function speakColumn(text) {
  let speech = new SpeechSynthesisUtterance(text);
  window.speechSynthesis.speak(speech);
}

// Get a prediction for the current video frame
function classifyVideo() {
  classifier.classifyStart(video, gotResult);
}

// When we get a result
function gotResult(results) {
  // console.log(results[0]);
  label = results[0].label;
}
