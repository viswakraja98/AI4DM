let video; 
let handPose; 
let hands = []; 

let triangles = []; 
let circles = []; 
let squares = []; 
let draggingTriangleIndex = -1;
let draggingCircleIndex = -1;
let draggingSquareIndex = -1;
let hoveringTriangleIndex = -1;
let hoveringCircleIndex = -1;
let hoveringSquareIndex = -1;
let label = "waiting...";
let classifier;
let modelURL = 'https://teachablemachine.withgoogle.com/models/83JPUkFXR/';

let gridColumns, gridRows;
let lastHoveredIndex = -1;
let videoAspectRatio;
let lastHoverTime = 0;
let lastLabel = ""; // Track the last detected label
let lastGridSpeakTime = 0; // Track the last time grid positions were spoken

function preload() {
  handPose = ml5.handPose({flipped: true});
  classifier = ml5.imageClassifier(modelURL + 'model.json');
}

function setup() {
  // Detect video & load ML model
  video = createCapture(VIDEO, {flipped: true}, () => {
    videoAspectRatio = video.width / video.height;
    resizeCanvas(video.width, video.height);
    setupGrid(); // Set up the grid after video dimensions are known
  });
  video.size(640, 480); // Set initial video dimensions
  video.hide();
  
  handPose.detectStart(video, gotHands);
  
  // Start classification with Teachable Machine
  classifier.classifyStart(video, gotResult);
}

function setupGrid() {
  // Grid setup based on video size
  gridColumns = width / 3; // Divide canvas width into 3 equal parts
  gridRows = height / 3; // Divide canvas height into 3 equal parts
}

function draw() {
  // Display video and hand tracking
  image(video, 0, 0, width, height);
  
  // Apply white translucent overlay on top of the video
  background(255, 255, 255, 200); // White background with 30% alpha (255 * 0.3 = 75)
  
  if (hands.length === 1) {
    let index = hands[0].keypoints[8];  // Index finger tip of first hand
    let thumb = hands[0].keypoints[4];   // Thumb tip of first hand

    // Draw points on index finger and thumb for visual feedback
    drawFingerPoints(index.x, index.y, thumb.x, thumb.y);

    // Pinch and move: check if distance between thumb and index finger is less than 20px
    if (dist(index.x, index.y, thumb.x, thumb.y) < 20) {
      checkShapeDrag(index.x, index.y, thumb.x, thumb.y); // Pinch and move elements
    }

  } else if (hands.length === 2) {
    let index1 = hands[0].keypoints[8];  // Index finger tip of first hand
    let index2 = hands[1].keypoints[8];  // Index finger tip of second hand

    // Draw points on both index fingers for visual feedback
    drawFingerPoints(index1.x, index1.y, index2.x, index2.y);

    // Check hover: only trigger hover when the index fingers of both hands are close together
    if (dist(index1.x, index1.y, index2.x, index2.y) < 30) {
      checkShapeHover(index1.x, index1.y); // Trigger hover
    }
  }

  // Draw grid
  drawGrid();

  // Check for label-based actions
  if (label === "triangle") {
    spawnTriangle(); // Spawn a new triangle when label is detected
    label = ""; // Reset label to avoid re-triggering
  } else if (label === "circle") {
    spawnCircle(); // Spawn a new circle when label is detected
    label = "";
  } else if (label === "square") {
    spawnSquare(); // Spawn a new square when label is detected
    label = "";
  } else if (label === "remove") {
    triangles = []; // Remove all triangles
    circles = []; // Remove all circles
    squares = []; // Remove all squares
    label = "";
  } else if (label === "grid") {
    speakGridPosition(); // Announce the grid position of all drawn elements
    label = ""; // Reset label to avoid re-triggering
  }

  // Draw triangles, circles, and squares
  for (let i = 0; i < triangles.length; i++) {
    drawTriangle(triangles[i].x, triangles[i].y, i === hoveringTriangleIndex);
  }
  for (let i = 0; i < circles.length; i++) {
    drawCircle(circles[i].x, circles[i].y, i === hoveringCircleIndex);
  }
  for (let i = 0; i < squares.length; i++) {
    drawSquare(squares[i].x, squares[i].y, i === hoveringSquareIndex);
  }
}

function gotHands(results) {
  hands = results;
}

// When we get a result from Teachable Machine
function gotResult(results) {
  // Update the label only if it's different from the last label
  if (results[0].label !== lastLabel) {
    label = results[0].label;
    lastLabel = label;
  }
}

function spawnTriangle() {
  let triangle = {
    x: gridColumns / 2, // Center of box 7 horizontally
    y: (gridRows * 2) + gridRows / 2 // Center of box 7 vertically
  };
  triangles.push(triangle); // Add it to the triangles array
}

function spawnCircle() {
  let circle = {
    x: gridColumns / 2, // Center of box 7 horizontally
    y: (gridRows * 2) + gridRows / 2 // Center of box 7 vertically
  };
  circles.push(circle); // Add it to the circles array
}

function spawnSquare() {
  let square = {
    x: gridColumns / 2, // Center of box 7 horizontally
    y: (gridRows * 2) + gridRows / 2 // Center of box 7 vertically
  };
  squares.push(square); // Add it to the squares array
}

function drawCircle(x, y, highlight) {
  noStroke();
  fill(highlight ? color(255, 204, 0, 150) : color(255, 204, 0)); // Highlight if hovering
  ellipse(x, y, 100, 100);
}

function drawTriangle(x, y, highlight) {
  noStroke();
  fill(highlight ? color(181, 242, 102, 150) : color(181, 242, 102)); // Highlight if hovering
  triangle(x - 50, y + 50, x, y - 50, x + 50, y + 50);
}

function drawSquare(x, y, highlight) {
  noStroke();
  fill(highlight ? color(0, 0, 255, 150) : color(84, 181, 255)); // Highlight if hovering
  rect(x - 50, y - 50, 100, 100);
}

function drawGrid() {
  stroke(0, 0, 0, 100);
  for (let i = 1; i <= 2; i++) {
    line(i * gridColumns, 0, i * gridColumns, height); // Vertical lines
    line(0, i * gridRows, width, i * gridRows); // Horizontal lines
  }

  // Label each box
  textSize(32);
  fill(0, 0, 0, 100);
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      text(3 * i + j + 1, (j + 0.5) * gridColumns, (i + 0.5) * gridRows);
    }
  }
}

function checkShapeDrag(indexX, indexY, thumbX, thumbY) {
  let distBetweenFingers = dist(indexX, indexY, thumbX, thumbY);

  // Check dragging for triangles
  for (let i = 0; i < triangles.length; i++) {
    if (distBetweenFingers < 20 && dist(triangles[i].x, triangles[i].y, (indexX + thumbX) / 2, (indexY + thumbY) / 2) < 100) {
      triangles[i].x = (indexX + thumbX) / 2;
      triangles[i].y = (indexY + thumbY) / 2;
      draggingTriangleIndex = i;
    }
  }

  // Check dragging for circles
  for (let i = 0; i < circles.length; i++) {
    if (distBetweenFingers < 20 && dist(circles[i].x, circles[i].y, (indexX + thumbX) / 2, (indexY + thumbY) / 2) < 100) {
      circles[i].x = (indexX + thumbX) / 2;
      circles[i].y = (indexY + thumbY) / 2;
      draggingCircleIndex = i;
    }
  }

  // Check dragging for squares
  for (let i = 0; i < squares.length; i++) {
    if (distBetweenFingers < 20 && dist(squares[i].x, squares[i].y, (indexX + thumbX) / 2, (indexY + thumbY) / 2) < 100) {
      squares[i].x = (indexX + thumbX) / 2;
      squares[i].y = (indexY + thumbY) / 2;
      draggingSquareIndex = i;
    }
  }
}

function checkShapeHover(indexX, indexY) {
  hoveringTriangleIndex = -1; // Reset hover state for triangles
  hoveringCircleIndex = -1; // Reset hover state for circles
  hoveringSquareIndex = -1; // Reset hover state for squares

  let hovered = false; // Track if any element is hovered

  // Check hovering for triangles
  for (let i = 0; i < triangles.length; i++) {
    if (dist(triangles[i].x, triangles[i].y, indexX, indexY) < 100) {
      hoveringTriangleIndex = i;
      speakHover("triangle", i); // Pass the index to prevent repeat TTS for same shape
      hovered = true;
    }
  }

  // Check hovering for circles
  for (let i = 0; i < circles.length; i++) {
    if (dist(circles[i].x, circles[i].y, indexX, indexY) < 100) {
      hoveringCircleIndex = i;
      speakHover("circle", i); // Pass the index to prevent repeat TTS for same shape
      hovered = true;
    }
  }

  // Check hovering for squares
  for (let i = 0; i < squares.length; i++) {
    if (dist(squares[i].x, squares[i].y, indexX, indexY) < 100) {
      hoveringSquareIndex = i;
      speakHover("square", i); // Pass the index to prevent repeat TTS for same shape
      hovered = true;
    }
  }

  if (hovered) {
    return; // Exit if any element was hovered
  }
}

function speakHover(shape, shapeIndex) {
  // Only trigger TTS if it's a new shape or if it's been more than 5 seconds since the last hover
  if (shapeIndex !== lastHoveredIndex || millis() - lastHoverTime > 5000) {
    let spokenText = `Hovering over the ${shape}.`;

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    // Speak the hover text
    let speech = new SpeechSynthesisUtterance(spokenText);
    window.speechSynthesis.speak(speech);

    lastHoveredIndex = shapeIndex; // Update last hovered shape
    lastHoverTime = millis(); // Update last hover time
  }
}

function speakGridPosition() {
  // Only speak grid positions if it hasn't been spoken in the last 5 seconds
  if (millis() - lastGridSpeakTime > 5000) {
    let spokenText = "";

    // Check and announce positions for all triangles
    for (let i = 0; i < triangles.length; i++) {
      let gridPositionTriangle = getGridPosition(triangles[i].x, triangles[i].y);
      spokenText += `A triangle is in box ${gridPositionTriangle}. `;
    }

    // Check and announce positions for all circles
    for (let i = 0; i < circles.length; i++) {
      let gridPositionCircle = getGridPosition(circles[i].x, circles[i].y);
      spokenText += `A circle is in box ${gridPositionCircle}. `;
    }

    // Check and announce positions for all squares
    for (let i = 0; i < squares.length; i++) {
      let gridPositionSquare = getGridPosition(squares[i].x, squares[i].y);
      spokenText += `A square is in box ${gridPositionSquare}. `;
    }

    // Speak the positions of all elements
    if (spokenText) {
      let speech = new SpeechSynthesisUtterance(spokenText);
      window.speechSynthesis.speak(speech);
      lastGridSpeakTime = millis(); // Update last grid speak time
    }
  }
}

function getGridPosition(x, y) {
  let column = Math.floor(x / gridColumns) + 1;
  let row = Math.floor(y / gridRows) + 1;
  return (row - 1) * 3 + column; // Calculate the grid number (1 to 9)
}

function drawFingerPoints(x1, y1, x2, y2) {
  fill(255, 0, 0);
  noStroke();
  
  // Draw small red circles at the points
  ellipse(x1, y1, 10, 10); // First point
  ellipse(x2, y2, 10, 10); // Second point
}